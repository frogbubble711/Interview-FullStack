export const SET_API_LOADING = 'global/set_api_loading';
export const SET_GLOBAL_NOTIFICATION = 'global/set_global_notification';
