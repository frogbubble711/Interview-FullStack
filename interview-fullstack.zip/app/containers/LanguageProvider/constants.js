/*
 *
 * LanguageProvider constants
 *
 */

export const DEFAULT_LOCALE = 'en';
export const CHANGE_LOCALE = 'app/LanguageToggle/CHANGE_LOCALE';
