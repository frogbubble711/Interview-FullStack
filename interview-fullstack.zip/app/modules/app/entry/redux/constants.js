// api
export const ENTRY_LIST_REQUEST = 'app/entry/list/request';
export const ENTRY_LIST_SUCCESS = 'app/entry/list/success';
export const ENTRY_LIST_ERROR = 'app/entry/list/error';
