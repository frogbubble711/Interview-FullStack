module.exports = {
  USER: 'user',
  STAKEHOLDER: 'stakeholder',
};
